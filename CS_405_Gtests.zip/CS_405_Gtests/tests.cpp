// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
   // FAIL();
//}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, what must the size be?
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, VerifyMaximumSize)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // is the collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // Collection size = 1
    add_entries(1);
    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
    // is the collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // Collection size = 5
    add_entries(4);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 5
    ASSERT_EQ(collection->size(), 5);
    // is the collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->max_size() >= collection->size());

    // Collection size = 10
    add_entries(5);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);
    // is collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->max_size() >= collection->size());

}
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, VerifyCapacity)
{
    // Collection size = 0
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
    // is collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // Collection size = 1
    add_entries(1);
    // is the collection still empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 1
    ASSERT_EQ(collection->size(), 1);
    // is collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // Collection size = 5
    add_entries(4);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 5
    ASSERT_EQ(collection->size(), 5);
    // is collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->capacity() >= collection->size());

    // Collection size = 10
    add_entries(5);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // if not empty, the size must be 10
    ASSERT_EQ(collection->size(), 10);
    // is collection max size greater or equal to its current size?
    ASSERT_TRUE(collection->capacity() >= collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizingIncreasesTheCollection)
{
    int increasedSize = NULL;

    // Collection size currently = 0
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);

    int initialSize = collection->size();

    // Collection resize = 5
    collection->resize(5);

    // increasedSize now equals the new collection size = 5
    increasedSize = collection->size();

    // is the collection still empty?
    ASSERT_FALSE(collection->empty());

    // Check that collection size has been increased = 5
    ASSERT_TRUE(collection->size() == 5);

    // Check that increasedSize is more than initialSize
    ASSERT_TRUE(initialSize < increasedSize);

    // collection size = 5
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizingDecreasesTheCollection)
{
    int decreasedSize = NULL;

    // Verify collection is empty
    ASSERT_TRUE(collection->empty());

    // Collection size currently = 10
    add_entries(10);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // collection size must be 10
    ASSERT_EQ(collection->size(), 10);

    int initialSize = collection->size();

    // Collection resize to 5
    collection->resize(5);

    // decreasedSize now equals the new collection size = 5
    decreasedSize = collection->size();

    // is the collection empty?
    ASSERT_FALSE(collection->empty());

    // Check that collection size has been increased = 5
    ASSERT_TRUE(collection->size() == 5);

    // Check that increasedSize is more than initialSize
    ASSERT_TRUE(decreasedSize < initialSize);

    // collection size must = 5
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, CollectionResizeToZero)
{
    // Verify collection is empty
    ASSERT_TRUE(collection->empty());

    // Collection size currently = 10
    add_entries(10);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // Collection size must = 10
    ASSERT_EQ(collection->size(), 10);

    // Collection resize to 0
    collection->resize(0);

    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // Check that collection size = 0
    ASSERT_TRUE(collection->size() == 0);
    // Collection size must = 0
    ASSERT_EQ(collection->size(), 0);
}


// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    // Verify collection is empty
    ASSERT_TRUE(collection->empty());

    // Collection size currently = 10
    add_entries(10);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // Collection size must = 10
    ASSERT_EQ(collection->size(), 10);

    // Clear Collection
    collection->clear();

    // is the collection now empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must = 0
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, CollectionBeginAndEndErase)
{
    // Verify collection is empty
    ASSERT_TRUE(collection->empty());

    // Collection size currently = 10
    add_entries(10);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // Collection size must = 10
    ASSERT_EQ(collection->size(), 10);

    
    std::vector<int>::iterator begin = collection->begin();
    std::vector<int>::iterator end = collection->end();

    
    collection->erase(begin, end);

    // is the collection now empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must = 0
    ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    int initialSize = NULL;
    int reservedSize = NULL;
    int initialCapacity = NULL;
    int reservedCapacity = 10;

    // Verify collection is empty
    ASSERT_TRUE(collection->empty());

    // Collection size currently =10
    add_entries(10);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // Collection size must = 10
    ASSERT_EQ(collection->size(), 10);

    initialSize = collection->size();
    initialCapacity = collection->capacity();

    
    ASSERT_TRUE(collection->size() == initialSize);
    ASSERT_TRUE(collection->capacity() == initialCapacity);

    collection->reserve(initialSize + reservedCapacity);

  
    reservedSize = collection->size();
    reservedCapacity = collection->capacity();


    ASSERT_TRUE(initialSize == reservedSize);
    ASSERT_FALSE(initialSize > reservedSize);
    ASSERT_FALSE(initialSize < reservedSize);

  
    ASSERT_TRUE(reservedCapacity > initialCapacity);
    ASSERT_FALSE(reservedCapacity == initialCapacity);
    ASSERT_FALSE(reservedCapacity < initialCapacity);

}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test

TEST_F(CollectionTest, VerifyIndexExceptionIsThrown)
{
    // Collection size currently = 0
    // is the collection empty?
    ASSERT_TRUE(collection->empty());
    // if empty, the size must = 0
    ASSERT_EQ(collection->size(), 0);

    // Collection size currently is 10
    add_entries(10);
    // is the collection empty?
    ASSERT_FALSE(collection->empty());
    // Collection size must =10
    ASSERT_EQ(collection->size(), 10);
    // Check that collection size = 10
    ASSERT_TRUE(collection->size() == 10);

    // Check if exception is thrown when trying to access index at 11 (not available since size is 10)
    ASSERT_THROW(collection->at(11), std::out_of_range);

}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// Positive Test: Verify that push_back adds an element to the end of the collection
TEST_F(CollectionTest, PushBackAddsElementToEnd) {
    collection->push_back(42);
    ASSERT_EQ(collection->back(), 42);
}

// Negative Test: Verify that accessing an invalid index throws an out_of_range exception
TEST_F(CollectionTest, AccessingInvalidIndexThrowsException) {
    add_entries(5);
    ASSERT_THROW(collection->at(100), std::out_of_range);
}